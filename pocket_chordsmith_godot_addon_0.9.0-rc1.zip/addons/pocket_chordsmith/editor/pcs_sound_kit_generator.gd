@tool
extends RefCounted
class_name PCSSoundKitGenerator

const DEFAULT_OUTPUT_DIR := "res://addons/pocket_chordsmith/audio/web_kit"
const SAMPLE_RATE := 44100
const TWO_PI := PI * 2.0


func generate_web_kit(output_dir := DEFAULT_OUTPUT_DIR) -> Dictionary:
	var result := {
		"ok": false,
		"output_dir": output_dir,
		"profile_path": "",
		"samples": {},
		"warnings": [],
		"errors": [],
	}
	var dir_error := _ensure_dir(output_dir)
	if dir_error != OK:
		result["errors"].append("Could not create sound kit folder %s: %s" % [output_dir, error_string(dir_error)])
		return result

	var samples := {
		"kick": _kick(0.95),
		"kick_accent": _kick(1.12),
		"snare": _snare(0.50, 1),
		"snare_accent": _snare(0.72, 2),
		"hat": _hat(0.16, false, 3),
		"open_hat": _hat(0.24, true, 4),
		"hat_accent": _hat(0.24, true, 4),
		"clap": _clap(0.34, 5),
		"warning_hit": _warning_hit(),
		"reward_hit": _reward_hit(),
		"transition_hit": _transition_hit(6),
	}

	var sample_paths := {}
	for sample_name in samples.keys():
		var path := output_dir.path_join("%s.wav" % sample_name)
		var error := _write_wav(path, samples[sample_name])
		if error == OK:
			sample_paths[sample_name] = path
		else:
			result["errors"].append("Could not save %s: %s" % [path, error_string(error)])

	if not result["errors"].is_empty():
		return result

	var profile_path := output_dir.path_join("pocket_chordsmith_web_kit_profile.tres")
	var profile_result := _save_profile(profile_path, sample_paths)
	result["warnings"].append_array(profile_result.get("warnings", []))
	result["errors"].append_array(profile_result.get("errors", []))
	result["profile_path"] = profile_path
	result["samples"] = sample_paths
	result["ok"] = result["errors"].is_empty()
	return result


func _save_profile(profile_path: String, sample_paths: Dictionary) -> Dictionary:
	var profile := PCSPlaybackProfile.new()
	profile.playback_backend = PCSPlaybackProfile.PlaybackBackend.HYBRID
	profile.max_polyphony = 24
	profile.mobile_safe = true
	profile.sample_preview_enabled = true
	profile.sample_preview_velocity_scale = true
	profile.drum_kit = {
		"kick": sample_paths.get("kick", ""),
		"kick_accent": sample_paths.get("kick_accent", ""),
		"snare": sample_paths.get("snare", ""),
		"snare_accent": sample_paths.get("snare_accent", ""),
		"hat": sample_paths.get("hat", ""),
		"hat_accent": sample_paths.get("hat_accent", sample_paths.get("open_hat", "")),
		"open_hat": sample_paths.get("open_hat", ""),
		"clap": sample_paths.get("clap", ""),
	}
	profile.accent_streams = {
		"warning_hit": sample_paths.get("warning_hit", ""),
		"reward_hit": sample_paths.get("reward_hit", ""),
		"transition_hit": sample_paths.get("transition_hit", ""),
	}
	profile.marker_stingers = {
		"boss_warning": "warning_hit",
		"reward": "reward_hit",
		"transition": "transition_hit",
	}
	profile.master_music_bus = "Music_Master"
	profile.drums_bus = "Music_Drums"
	profile.stingers_bus = "Music_Stingers"
	var error := ResourceSaver.save(profile, profile_path)
	return {
		"ok": error == OK,
		"errors": [] if error == OK else ["Could not save playback profile %s: %s" % [profile_path, error_string(error)]],
		"warnings": [],
	}


func _kick(peak: float) -> PackedFloat32Array:
	var duration := 0.18
	var total := int(SAMPLE_RATE * duration)
	var out := PackedFloat32Array()
	out.resize(total)
	var phase := 0.0
	for i in range(total):
		var t := float(i) / float(SAMPLE_RATE)
		var n := t / duration
		var freq := lerp(155.0, 45.0, 1.0 - pow(0.001, n))
		phase += TWO_PI * freq / float(SAMPLE_RATE)
		var env: float = max(0.0, peak) * exp(-30.0 * t)
		out[i] = sin(phase) * env
	return _normalize(out, 0.98)


func _snare(peak: float, seed: int) -> PackedFloat32Array:
	var duration := 0.14
	var total := int(SAMPLE_RATE * duration)
	var rng := RandomNumberGenerator.new()
	rng.seed = seed
	var noise := PackedFloat32Array()
	noise.resize(total)
	for i in range(total):
		var t := float(i) / float(SAMPLE_RATE)
		var env: float = max(0.05, peak) * exp(-34.0 * t)
		var body: float = sin(TWO_PI * 185.0 * t) * env * 0.16
		noise[i] = (rng.randf() * 2.0 - 1.0) * env + body
	return _normalize(_highpass(noise, 1700.0), 0.88)


func _hat(peak: float, open: bool, seed: int) -> PackedFloat32Array:
	var duration := 0.16 if open else 0.055
	var total := int(SAMPLE_RATE * duration)
	var rng := RandomNumberGenerator.new()
	rng.seed = seed
	var data := PackedFloat32Array()
	data.resize(total)
	for i in range(total):
		var t := float(i) / float(SAMPLE_RATE)
		var env: float = max(0.03 if not open else 0.05, peak) * exp((-18.0 if open else -82.0) * t)
		var metallic := sin(TWO_PI * 7700.0 * t) * 0.18 + sin(TWO_PI * 10400.0 * t) * 0.12
		data[i] = ((rng.randf() * 2.0 - 1.0) + metallic) * env
	return _normalize(_highpass(data, 3800.0 if open else 5600.0), 0.62)


func _clap(peak: float, seed: int) -> PackedFloat32Array:
	var duration := 0.18
	var total := int(SAMPLE_RATE * duration)
	var rng := RandomNumberGenerator.new()
	rng.seed = seed
	var data := PackedFloat32Array()
	data.resize(total)
	for i in range(total):
		var t := float(i) / float(SAMPLE_RATE)
		var burst := 0.0
		for offset in [0.0, 0.018, 0.036]:
			if t >= offset:
				burst += exp(-55.0 * (t - offset))
		data[i] = (rng.randf() * 2.0 - 1.0) * peak * burst
	return _normalize(_highpass(data, 1350.0), 0.78)


func _warning_hit() -> PackedFloat32Array:
	var duration := 0.42
	var total := int(SAMPLE_RATE * duration)
	var data := PackedFloat32Array()
	data.resize(total)
	var phase := 0.0
	for i in range(total):
		var t := float(i) / float(SAMPLE_RATE)
		var freq := 340.0 + sin(TWO_PI * 7.0 * t) * 48.0
		phase += TWO_PI * freq / float(SAMPLE_RATE)
		var env: float = min(1.0, t / 0.015) * exp(-5.2 * t)
		data[i] = sin(phase) * 0.55 * env
	return _normalize(data, 0.8)


func _reward_hit() -> PackedFloat32Array:
	var duration := 0.62
	var total := int(SAMPLE_RATE * duration)
	var data := PackedFloat32Array()
	data.resize(total)
	for i in range(total):
		var t := float(i) / float(SAMPLE_RATE)
		var value := 0.0
		for spec in [[523.25, 0.0], [659.25, 0.055], [783.99, 0.11]]:
			var start := float(spec[1])
			if t >= start:
				var local_t := t - start
				var env: float = min(1.0, local_t / 0.01) * exp(-6.0 * local_t)
				value += sin(TWO_PI * float(spec[0]) * local_t) * env * 0.28
		data[i] = value
	return _normalize(data, 0.84)


func _transition_hit(seed: int) -> PackedFloat32Array:
	var duration := 0.36
	var total := int(SAMPLE_RATE * duration)
	var rng := RandomNumberGenerator.new()
	rng.seed = seed
	var data := PackedFloat32Array()
	data.resize(total)
	for i in range(total):
		var t := float(i) / float(SAMPLE_RATE)
		var env: float = min(1.0, t / 0.02) * exp(-8.0 * t)
		data[i] = (rng.randf() * 2.0 - 1.0) * env * 0.42
	return _normalize(_highpass(data, 900.0), 0.72)


func _highpass(input: PackedFloat32Array, cutoff_hz: float) -> PackedFloat32Array:
	var out := PackedFloat32Array()
	out.resize(input.size())
	if input.is_empty():
		return out
	var dt := 1.0 / float(SAMPLE_RATE)
	var rc := 1.0 / (TWO_PI * cutoff_hz)
	var alpha := rc / (rc + dt)
	var last_y := 0.0
	var last_x := float(input[0])
	for i in range(input.size()):
		var x := float(input[i])
		var y := alpha * (last_y + x - last_x)
		out[i] = y
		last_y = y
		last_x = x
	return out


func _normalize(input: PackedFloat32Array, target_peak: float) -> PackedFloat32Array:
	var peak := 0.0
	for sample in input:
		peak = max(peak, absf(float(sample)))
	if peak <= 0.00001:
		return input
	var gain := target_peak / peak
	var out := PackedFloat32Array()
	out.resize(input.size())
	for i in range(input.size()):
		out[i] = clamp(float(input[i]) * gain, -1.0, 1.0)
	return out


func _write_wav(path: String, samples: PackedFloat32Array) -> int:
	var file := FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		return FileAccess.get_open_error()
	var data_size := samples.size() * 2
	file.store_buffer("RIFF".to_ascii_buffer())
	_store_u32_le(file, 36 + data_size)
	file.store_buffer("WAVE".to_ascii_buffer())
	file.store_buffer("fmt ".to_ascii_buffer())
	_store_u32_le(file, 16)
	_store_u16_le(file, 1)
	_store_u16_le(file, 1)
	_store_u32_le(file, SAMPLE_RATE)
	_store_u32_le(file, SAMPLE_RATE * 2)
	_store_u16_le(file, 2)
	_store_u16_le(file, 16)
	file.store_buffer("data".to_ascii_buffer())
	_store_u32_le(file, data_size)
	for sample in samples:
		var value := int(round(clamp(float(sample), -1.0, 1.0) * 32767.0))
		if value < 0:
			value = 65536 + value
		_store_u16_le(file, value)
	file.close()
	return OK


func _store_u16_le(file: FileAccess, value: int) -> void:
	file.store_8(value & 0xff)
	file.store_8((value >> 8) & 0xff)


func _store_u32_le(file: FileAccess, value: int) -> void:
	file.store_8(value & 0xff)
	file.store_8((value >> 8) & 0xff)
	file.store_8((value >> 16) & 0xff)
	file.store_8((value >> 24) & 0xff)


func _ensure_dir(path: String) -> int:
	var global_path := ProjectSettings.globalize_path(path)
	return DirAccess.make_dir_recursive_absolute(global_path)
